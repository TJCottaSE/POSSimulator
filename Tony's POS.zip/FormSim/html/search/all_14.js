var searchData=
[
  ['write',['Write',['../class_form_sim_1_1_log_writer.html#a68f7b66a739339396ee0b575813fd986',1,'FormSim.LogWriter.Write(string value)'],['../class_form_sim_1_1_log_writer.html#ade1899b921aefffbe53695cfde35cd99',1,'FormSim.LogWriter.Write(char value)'],['../class_form_sim_1_1_log_writer.html#a50cd130c993c0412f9e563f9baabb8b4',1,'FormSim.LogWriter.Write(byte value)']]]
];
