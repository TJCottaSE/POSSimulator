var searchData=
[
  ['fastemv',['fastEMV',['../class_form_sim_1_1_i_d_tech_handler.html#a280030b3a56291c1914f53de368bf65a',1,'FormSim.IDTechHandler.fastEMV()'],['../class_form_sim_1_1_i_d_tech_handler.html#a5d9c224bcb3915493029fc7b58df2b97',1,'FormSim.IDTechHandler.FastEMV()']]],
  ['foodandbeverage',['FoodAndBeverage',['../class_form_sim_1_1_form1.html#a5aaef580c721c58b391c31253d543ece',1,'FormSim::Form1']]],
  ['foodandbeverage_5fcheckedchanged',['FoodAndBeverage_CheckedChanged',['../class_form_sim_1_1_form1.html#a7c36bc29aa6d9fc704fcee5fc434973c',1,'FormSim::Form1']]],
  ['form1',['Form1',['../class_form_sim_1_1_form1.html',1,'FormSim.Form1'],['../class_form_sim_1_1_form1.html#aaf140bd5cccdffe2b9f6c4a9b856b5ca',1,'FormSim.Form1.Form1()']]],
  ['form1_2ecs',['Form1.cs',['../_form1_8cs.html',1,'']]],
  ['form1_2edesigner_2ecs',['Form1.Designer.cs',['../_form1_8_designer_8cs.html',1,'']]],
  ['formsim',['FormSim',['../namespace_form_sim.html',1,'']]],
  ['frc_5fhandler',['FRC_Handler',['../interface_form_sim_1_1_f_r_c___handler.html',1,'FormSim']]],
  ['frc_5fhandler_2ecs',['FRC_Handler.cs',['../_f_r_c___handler_8cs.html',1,'']]],
  ['functionrequestcode',['FunctionRequestCode',['../class_form_sim_1_1_form1.html#a46991f1bba83499f54cf854581c14784',1,'FormSim::Form1']]]
];
