var searchData=
[
  ['verify_5fcard',['VERIFY_CARD',['../class_form_sim_1_1_rest_handler.html#adbde7c45aab3b4a97cf1464065161dcd',1,'FormSim::RestHandler']]],
  ['voidinvalidavs',['VoidInvalidAVS',['../class_form_sim_1_1_form1.html#aa0f74345c5136c35a702e5670cac3f3b',1,'FormSim::Form1']]],
  ['voidinvalidcvv2',['VoidInvalidCVV2',['../class_form_sim_1_1_form1.html#ae1cc93ed604fda928b9751fecf1d4873',1,'FormSim::Form1']]],
  ['voidtransaction',['voidTransaction',['../class_form_sim_1_1_h_t_t_p_handler.html#a9b0d19f62c0e810686bfafe5b7c1635e',1,'FormSim.HTTPHandler.voidTransaction()'],['../class_form_sim_1_1_rest_handler.html#a7c2e17caa0c591a104e9e4f9a3825f47',1,'FormSim.RestHandler.voidTransaction()'],['../class_form_sim_1_1_t_c_p_handler.html#a3c510f254bcd72de16d7824b89202878',1,'FormSim.TCPHandler.voidTransaction()']]]
];
