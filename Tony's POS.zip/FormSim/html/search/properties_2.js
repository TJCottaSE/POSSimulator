var searchData=
[
  ['getinstance',['getInstance',['../class_form_sim_1_1_helper.html#ac61d1dca7ce9b1fa7e4ce17e99b0b7e1',1,'FormSim.Helper.getInstance()'],['../class_form_sim_1_1_log_writer.html#ac885dc41c236f618e066cdcee8189f64',1,'FormSim.LogWriter.getInstance()']]]
];
