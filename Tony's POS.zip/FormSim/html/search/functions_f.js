var searchData=
[
  ['voidtransaction',['voidTransaction',['../class_form_sim_1_1_h_t_t_p_handler.html#a9b0d19f62c0e810686bfafe5b7c1635e',1,'FormSim.HTTPHandler.voidTransaction()'],['../class_form_sim_1_1_rest_handler.html#a7c2e17caa0c591a104e9e4f9a3825f47',1,'FormSim.RestHandler.voidTransaction()'],['../class_form_sim_1_1_t_c_p_handler.html#a3c510f254bcd72de16d7824b89202878',1,'FormSim.TCPHandler.voidTransaction()']]]
];
